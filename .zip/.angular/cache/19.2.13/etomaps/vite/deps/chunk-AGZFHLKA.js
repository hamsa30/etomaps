// node_modules/@angular/cdk/fesm2022/boolean-property-DaaVhX5A.mjs
function coerceBooleanProperty(value) {
  return value != null && `${value}` !== "false";
}

export {
  coerceBooleanProperty
};
//# sourceMappingURL=chunk-AGZFHLKA.js.map
